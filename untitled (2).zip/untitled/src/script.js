function goTo(pageName) {

  var pages = document.querySelectorAll(".page");

  for (var i = 0; i < pages.length; i++) {
    pages[i].classList.remove("active");
  }

  var page = document.getElementById(pageName);

  if (page) {
    page.classList.add("active");
    window.scrollTo(0, 0);
  }
}


function startLearning() {
  goTo("grades");
}


function chooseGrade(grade) {

  var title = document.getElementById("gradeTitle");

  if (title) {
    title.innerText = "📚 مواد " + grade;
  }

  goTo("subjects");
}


function chooseSubject(subject) {

  var title = document.getElementById("subjectTitle");

  if (title) {
    title.innerText = "📖 " + subject;
  }

  goTo("lesson");
}


function correctAnswer() {

  var result = document.getElementById("quizResult");
  var points = document.getElementById("points");

  if (result) {
    result.innerText = "🎉 برافو! إجابة صحيحة +10 نقاط ⭐";
  }

  if (points) {
    points.innerText = "10";
  }
}


function wrongAnswer() {

  var result = document.getElementById("quizResult");

  if (result) {
    result.innerText = "😄 ولا يهمك! حاول تاني.";
  }
}


function askNabta() {

  var input = document.getElementById("question");
  var chat = document.getElementById("chat");

  if (!input || !chat) {
    return;
  }

  var text = input.value.trim();

  if (text === "") {
    return;
  }

  var userMessage = document.createElement("div");

  userMessage.className = "user";
  userMessage.innerText = text;

  chat.appendChild(userMessage);


  var botMessage = document.createElement("div");

  botMessage.className = "bot";

  botMessage.innerText =
    "🌱 فهمتك! دي نسخة نَبْتة التجريبية. " +
    "قريبًا هنربط المساعد بذكاء اصطناعي حقيقي عشان يشرح لك السؤال خطوة بخطوة.";

  chat.appendChild(botMessage);


  input.value = "";

  chat.scrollTop = chat.scrollHeight;
}